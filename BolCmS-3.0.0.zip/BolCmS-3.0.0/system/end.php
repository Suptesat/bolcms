<?php 
//ноги сайта
echo '<div class="phdr">';


echo '<div class="rmenus"><center><a href="http://bolcms.cf">BolCmS</center></a></div>';


echo'<center><a href="http://johntop.ru/in/1862"><img src="http://johntop.ru/image/1862" alt="JohnTOP"/></center></a>';
echo'';

echo '</div></body></html>';
?>