<?php 

// шапка сайта
echo '<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">';
echo '<html>';
echo '<head>';
echo '<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />';
echo '<title>'.$title.' - '.$config['title'].'</title>';
echo '<link href="../theme/'.$config['style'].'.css" rel="stylesheet" type="text/css" />';
echo '</head>';
echo '<body>';

// sec
function sec($sec){
 $sec = htmlspecialchars(mysql_real_escape_string($sec));
 return $sec;
}

// показ заголовка
function tp($tp){
 echo '<div class="tp">'.$tp.'</div>';
}

// показ ошибок
function error($error){
 echo '<div class="phdr">Ошибка!</div><div class="phdr">'.$error.'</div>';
}

// показ информации
function info($info){
 echo '<div class="phdr">Информация</div><div class="phdr">'.$info.'</div>';
}

// навигация "на главную"
function nav(){
echo '<div class="phdr"><li><a href="../">На главную</a></div>';
}

// навигация "одна ссылка + на главную"
function nav2($link, $link_name){
 echo '<div class="phdr">Навигация</div><div class="bmenu"><a href="'.$link.'">'.$link_name.'</a><br/><a href="../">на главную</a></div>';
}

// постраничная навигация "пред, след"
function navig($page, $link, $pages){
if($page>1) echo '&larr;<a href="'.$link.'page='.($page-1).'">пред.</a>|';
if($page<$pages) echo '<a href="'.$link.'page='.($page+1).'">след.</a>&rarr;<br/>';
}

//фильтрация
function filtr($input, $sql=false){ 
    $input = htmlentities($input, ENT_QUOTES, 'UTF-8'); 


   if(get_magic_quotes_gpc ()) 
    { 
        $input = stripslashes ($input); 

    } 
        if ($sql) 
    { 
        $input = mysql_real_escape_string ($input); 
       
    } 
    $input = strip_tags($input); 
     
 return $input; 
}







?>