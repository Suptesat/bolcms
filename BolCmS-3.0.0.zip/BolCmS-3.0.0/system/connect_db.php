<?php 

$db = mysql_connect("localhost", "БАЗА", "ПАРОЛЬ");
mysql_select_db("БАЗА", $db) or die('Ошибка подключения к БД');
mysql_query('SET NAMES utf8');

?>