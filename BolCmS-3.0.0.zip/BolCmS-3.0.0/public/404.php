<?php
$title = 'Ошибка 404';
require("../system/connect_db.php");
require("../system/head.php");
require("../system/functions.php");
echo "<div class='phdr'>Ошибка. Страницы несуществует!</div>";
echo "<div class='menu'>Номер : 404</div>";
require("../system/end.php");
?>
