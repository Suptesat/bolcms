BolCmS ver 2.0.0
Автор -Suptesat
Контакты:
mk.kikmret@mail.ru
https://m.vk.com/id301267683

Официальный сайт поддержки движка  :
http://bolcms.cf/


УСТАНОВКА:
-Прописать даные базы в файле config.php 
-Пройти install.php 
-Админ с id1.Доступ в админ-панель по сессии.

Установка завершена!