<?php 
$title = 'Главная';
require("../system/connect_db.php");
require("../system/head.php");
require("../system/functions.php");


$forum_topics = mysql_result(mysql_query("SELECT count(*) FROM `forum_topics`"), 0);
$forum_msg = mysql_result(mysql_query("SELECT count(*) FROM `forum_msg`"), 0);
$library = mysql_result(mysql_query("SELECT count(*) FROM `library`"), 0); 
$book_msg = mysql_result(mysql_query("SELECT count(*) FROM `book`"), 0); 
$loads = mysql_result(mysql_query("SELECT count(*) FROM `loads`"), 0); 
$users = mysql_result(mysql_query("SELECT count(*) FROM `users`"), 0);

if(empty($_SESSION['login'])){
echo '<div class="rmenus"> Гость <b></b></div><div class="menu">';
echo '<center><div class="menu"><li><a href="users/auth.php">Вход</a> | ';
echo '<a href="users/reg.php">Регистрация</a></div></center>';
}else{
echo '<div class="rmenus"><a href="users/office.php">'.$_SESSION['login'].'</a></div>';
echo'<div class="rmenus2"><a href="users/office.php?act=exit">Выход</a></div>';}

if($_SESSION['id'] == 1){echo '<div class="menu"> <a href="../panel/index.php">Админ-Панель</a></div>';}
echo '<div class="menu"><li><a href="../forum/index.php">Форум</a> ('.$forum_topics.'/'.$forum_msg.')</div>';
echo '<div class="menu"><li><a href="str/book.php">Чат</a> ('.$book_msg.')</div>';
echo '</div>';

echo '<div class="phdr">Новости</div><div class="news">';

$result = mysql_query("SELECT * FROM `news` ORDER BY `id` DESC LIMIT 2") or die(mysql_error());
$row = mysql_fetch_assoc($result);
if($row > 0){
echo '<a href="../str/news.php">читать все новости</a><br/>';
 do
 {
printf('<b>%s</b>: %s<br/>%s...<br/><a href="../str/news.php?act=view&amp;id=%s">подробнее</a><br/>', $row['title'], date('d.m.Y', $row['time']), substr($row['text'], 0, 95), $row['id']);
 }
 while($row = mysql_fetch_assoc($result));
}else{
 echo 'Новостей пока нет';
}

echo '</div>';

echo '<div class="phdr">Разделы</div><div class="menu">';

echo '<div class="menu"><li><a href="loads/index.php">Загрузки</a> ('.$loads.')</div>';
echo '<div class="menu"><li><a href="str/lib.php">Библиотека</a> ('.$library.')</div>';
echo '<div class="menu"><li><a href="users/list_users.php">Пользователи</a> ('.$users.')</div>';
echo '<div class="menu"><a href="users/life.php"><li>Жизнь сайта</a></div>';
echo '</div>';
echo '<div class="phdr"><center><li>By Suptesat</center>';

echo '<div class="phdr"><center><li>'.$config['title'].'</center></div>';
echo'</b></br>';

echo '</div></body></html>';
require("../system/end.php");
?>