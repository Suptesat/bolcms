<?php 
require("../system/connect_db.php");
require("../system/head.php");

echo '<div class="phdr">Форум</div>';

$id = intval($_REQUEST['id']);

$topic = mysql_fetch_assoc(mysql_query("SELECT * FROM `forum_topics` WHERE `id` = '$id'"));

$title = $topic['title'];
require("../system/functions.php");

if(isset($topic['id'])){
echo '<div class="phdr">'.$topic['title'].'</div><div class="bmenu">';
	if(empty($_REQUEST['page']) or $_REQUEST['page'] == 1){
		echo '<b>'.$topic['authour'].'</b>: '.date('d.m.Y / H:i', $topic['time']).'<br/>'.$topic['text'].'<br/>';
$col = mysql_result(mysql_query("SELECT COUNT(*) FROM `forum_msg` WHERE `id_topic` = '$id'"), 0);
echo '<div class="bmenu">Коментариев: '.$col.'</div>';
	}

	$count = mysql_result(mysql_query("SELECT COUNT(*) FROM `forum_msg` WHERE `id_topic` = '$id'"), 0);
	if($count > 0){
		$pages = ceil($count/$config['onpage']);
		$page = abs(intval(@$_REQUEST['page']));
		if($page == 0) $page = 1;
		$from = ($page-1)*$config['onpage'];

		$result = mysql_query("SELECT * FROM `forum_msg` WHERE `id_topic` = '$id' ORDER BY `time` LIMIT $from, ".$config['onpage']."");
		while($msg = mysql_fetch_assoc($result)){
			echo '<b><a href="posting.php?act=answer&amp;id='.$msg['id'].'">'.$msg['authour'].'</a></b> <i>'.date('d.m.Y / H:i', $msg['time']).'</i>';
if($_SESSION['id'] == 1){echo ' (<a href="../panel/forum.php?act=msg_del&amp;topic_id='.$id.'&amp;id='.$msg['id'].'">Удалить</a>)';}
			echo '<br/>'.$msg['text'].'<br/>';
		}
	}
	if($_SESSION['id'] == 1){
	$clos = mysql_fetch_array(mysql_query("SELECT * FROM `forum_topics`"));
	echo '<br/>(<a href="../panel/forum.php?act=topic_del&amp;id='.$id.'">Удалить тему</a>)<br />';
	$close = $clos['closed'];
	$xTo = $clos['ktoclosed'];
	if ($close  == 0) {
	echo '(<a href="?act=close&amp;id='.$topic['id'].'">Закрыть тему</a>)';
	}
	if ($close == 1) {
	echo '(<a href="?act=open&amp;id='.$topic['id'].'">Открыть тему</a>)';
	}
	}
	echo '</div>';
	if ($close == 1) {
	echo '<div class="s1">Темк0 закрыто модератором '.$clos['ktoclosed'].'!!!бггг</div>';
	}
echo '<div class="phdr"></div><div class="bmenu">';
	navig($page, 'index.php?act=topic_view&amp;id='.$id.'&amp;', $pages);
	if(!empty($_SESSION['login'])){
	if ($close == 0) {
		echo 'Добавить сообщение:<br/>';
		echo '<form action="posting.php?act=add_msg&amp;id_cat='.$topic['id_cat'].'&amp;id_topic='.$topic['id'].'" method="post" name="form">';
		echo '<textarea name="text" rows="3"></textarea><br/>';
		echo '<input name="submit" type="submit" value="Добавить" /></form><br/>';
		}
	}
	echo '<a href="index.php?act=cat_view&amp;id='.$topic['id_cat'].'">в раздел</a><br/><a href="../">на главную</a></div>';
}else{
	error('Выбранной темы не существует!');
	nav2('./', 'форум');
}
switch($_GET['act']){
default;
case 'close':
if($_SESSION['id'] == 1){
$ok = mysql_query("UPDATE `forum_topics` SET `closed` = '1', `ktoclosed`= '$_SESSION[login]' WHERE `id` = '$topic[id]'");
}
break;
case 'open':
if($_SESSION['id'] == 1){
$ok = mysql_query("UPDATE `forum_topics` SET `closed` = '0', `ktoclosed` = 'JIox' WHERE `id` = '$topic[id]'");
}
break;
}
require("../system/end.php");
?>