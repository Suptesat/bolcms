<?php 
$title = 'Форум';
require("../system/connect_db.php");
require("../system/head.php");
require("../system/functions.php");

switch($_GET['act']){

default:

echo '<div class="phdr">Форум</div><div class="bmenu">';

$result = mysql_query("SELECT * FROM `forum_cats`");

while($row = mysql_fetch_assoc($result)){
	$topics = mysql_result(mysql_query("SELECT COUNT(*) FROM `forum_topics` WHERE `id_cat` = ".$row['id'].""), 0);
	$msg = mysql_result(mysql_query("SELECT COUNT(*) FROM `forum_msg` WHERE `id_cat` = ".$row['id'].""), 0);
echo '<div class="menu"><li><a href="index.php?act=cat_view&amp;id='.$row['id'].'">'.$row['name'].'</a> ('.$topics.'/'.$msg.')<br/></div>';
}

echo '</div>';
nav();

break;

case 'cat_view':

$id = intval($_REQUEST['id']);

$row = mysql_fetch_assoc(mysql_query("SELECT * FROM `forum_cats` WHERE `id` = '$id'"));
if(isset($row['id'])){
echo '<div class="phdr">'.$row['name'].'</div><div class="menu">';
	$count = mysql_result(mysql_query("SELECT COUNT(*) FROM `forum_topics` WHERE `id_cat` = '$id'"), 0);
	if($count > 0){
		$pages = ceil($count/$config['onpage']);
		$page = abs(intval(@$_REQUEST['page']));
		if($page == 0) $page = 1;
		$from = ($page-1)*$config['onpage'];

		$result = mysql_query("SELECT * FROM `forum_topics` WHERE `id_cat` = '$id' ORDER BY `time` DESC LIMIT $from, ".$config['onpage']."");
		while($row = mysql_fetch_assoc($result)){
			$forum_msg = mysql_result(mysql_query("SELECT COUNT(`id`) FROM `forum_msg` WHERE `id` = '".$row['id']."'"), 0);
echo '<div class="menu"><li><a href="topic.php?id='.$row['id'].'">'.$row['title'].'</a>['.$forum_msg.'] '.$row['authour'].'<br/></div>';
		}
	}else{
		echo 'Этот раздел еще пуст<br/>';
	}

	echo '<br/><a href="posting.php?act=add_topic&amp;id='.$id.'" class="button">Новая тема</a></div>';

echo '</div><div class="phdr"></div><div class="bmenu">';
	navig($page, 'index.php?act=cat_view&amp;id='.$id.'&amp;', $pages);
echo '<a href="./">Форум</a><br/><a href="../">На главную</a></div>';
}else{
	error('Такого раздела не существует!');
	nav2('./', 'форум');
}
break;

}

require("../system/end.php");
?>