<?php 
$title = 'Начать новую тему - Форум';
require("../system/connect_db.php");
require("../system/head.php");
require("../system/functions.php");

$id = intval($_REQUEST['id']);

switch($_GET['act']){

case 'add_topic':

if(!empty($_SESSION['login'])){
echo '<div class="phdr">Начать новую тему</div><div class="bmenu">';
	echo '<form action="posting.php?act=added_topic&amp;id='.$id.'" method="post" name="form">';
	echo 'Название:<br/><input name="title" type="text" maxlength="25" /><br/>';
	echo 'Сообщение:<br/><textarea name="text" rows="4"></textarea><br/>';
	echo '<input name="submit" type="submit" value="Создать тему" /></form></div>';
	nav2('index.php?act=cat_view&amp;id='.$id.'', 'к разделу');
}else{
	error('Вы не авторизованы для создания темы!');
	nav2('index.php?act=cat_view&amp;id='.$id.'', 'назад');
}

break;

case 'added_topic':

if(!empty($_POST['title']) && !empty($_POST['text'])){
	$title = sec($_POST['title']);
	$text = sec($_POST['text']);

	mysql_query("INSERT INTO `forum_topics` SET `id_cat` = '$id', `title` = '$title', `text` = '$text', `authour` = '".$_SESSION['login']."', `time` = '".time()."'");
	info('Тема успешно создана!');
	nav2('index.php?act=cat_view&amp;id='.$id.'', 'к разделу');
}else{
	error('Вы не заполнили поля!');
	nav2('posting.php?act=add_topic&amp;id='.$id.'', 'назад');
}

break;

case 'add_msg':

$id_cat = intval($_REQUEST['id_cat']);
$id_topic = intval($_REQUEST['id_topic']);

if(!empty($_POST['text'])){
	$text = sec($_POST['text']);
	mysql_query("INSERT INTO `forum_msg` SET `id_cat` = '$id_cat', `id_topic` = '$id_topic', `text` = '$text', `authour` = '".$_SESSION['login']."', `time` = '".time()."'") or die(mysql_error());
	info('Ваше сообщение успешно добавлено!');
	nav2('topic.php?id='.$id_topic.'', 'назад');
}else{
	error('Вы не заполнили поле!');
	nav2('topic.php?id='.$id_topic.'', 'назад');
}

break;

case 'answer':

$row = mysql_fetch_assoc(mysql_query("SELECT * FROM `forum_msg` WHERE `id` = '$id'"));
if(isset($row['id'])){
echo '<div class="phdr">Ответ пользователю '.$row['authour'].'</div><div class="bmenu">';
	echo '<form action="?act=answered&amp;id='.$id.'" method="post" name="form">';
	echo '<textarea name="text" rows="4">'.$row['authour'].', </textarea>';
	echo '<input name="submit" type="submit" value="Ответить" /></form></div>';
	nav2('topic.php?id='.$row['id_topic'].'', 'назад');
}else{
	error('Сообщение, на которое вы хотите ответить не существует!');
	nav();
}
break;

case 'answered':

$text = sec($_POST['text']);
if(!empty($_POST['text'])){
	$row = mysql_fetch_assoc(mysql_query("SELECT * FROM `forum_msg` WHERE `id` = '$id'"));
	mysql_query("INSERT INTO `forum_msg` SET `id_cat` = '".$row['id_cat']."', `id_topic` = '".$row['id_topic']."', `text` = '$text', `authour` = '".$_SESSION['login']."', `time` = '".time()."'");
	info('Вы успешно оставили ответ!');
	nav2('topic.php?id='.$row['id_topic'].'', 'назад');
}else{
	error('Вы не заполнили поле!');
	nav2('posting.php?act=answer&amp;id='.$id.'', 'назад');
}
break;

}
require("../system/end.php");
?>