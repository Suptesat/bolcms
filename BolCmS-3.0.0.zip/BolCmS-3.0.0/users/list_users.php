<?php 
$title = 'Пользователи сайта';
require("../system/connect_db.php");
require("../system/head.php");
require("../system/functions.php");

echo '<div class="phdr">Список</div><div
class="bmenu">';

$result = mysql_query("SELECT * FROM `users` ORDER BY `reg_time` DESC");
while($user = mysql_fetch_assoc($result)){
echo '<div class="gmenu"><a href="profile.php?id='.$user['id'].'">'.$user['login'].'</a></div>';
}

echo '</div>';
nav();

require("../system/end.php");
?>