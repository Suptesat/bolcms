<?php 
$title = 'Регистрация';
require("../system/connect_db.php");
require("../system/head.php");
require("../system/functions.php");


switch($_GET['act']){
default:

echo '<div class="phdr">Регистрация</div><div class="bmenu">';
echo '<form action="?act=reg_do" method="post" name="form">';
echo 'Логин:<br/><input name="login" type="text" maxlength="40" /><br/>';
echo 'E-mail:<br/><input name="mail" type="text" maxlength="20" /><br/>';
echo 'Пароль:<br/><input name="pass" type="password" maxlength="30" /><br/>';

$_SESSION['captcha'] = rand(1234, 9999);
echo 'Введите число: <b>'.$_SESSION['captcha'].'</b><br/><input name="captcha" type="text" maxlength="6" /><br/>';
echo '<input name="submit" type="submit" value="Регистрация" /></form></div>';
nav();

break;

case 'reg_do':

if(!empty($_POST['login']) && !empty($_POST['mail']) && !empty($_POST['pass'])){
if(strlen($_POST['login']) >= 3 && strlen($_POST['login']) <= 40){
if(strlen($_POST['mail']) >= 5 && strlen($_POST['mail']) <= 20){
if(strlen($_POST['pass']) >= 3 && strlen($_POST['pass']) <= 30){
if($_SESSION['captcha'] == $_POST['captcha']){
			
 $login = sec($_POST['login']);
 $mail = sec($_POST['mail']);
 $pass = md5(sec($_POST['pass']));
 
 $same_login = mysql_result(mysql_query("SELECT count(*) FROM `users` WHERE `login` = '$login'"), 0);
 if($same_login == 0){
 $same_mail = mysql_result(mysql_query("SELECT count(*) FROM `users` WHERE `mail` = '$mail'"), 0);
 if($same_mail == 0){

  mysql_query("INSERT INTO `users` SET `login` = '$login', `mail` = '$mail', `pass` = '$pass', `reg_time` = '".time()."'");
echo '<div class="phdr">Информация</div><div class="menu">Вы успешно зарегистрированы! Вы можете войти используя ваш логин и пароль</div>';
  nav();

 }else{error('Пользователь с таким e-mail уже существует!'); nav2('reg.php', 'назад');}			
 }else{error('Пользователь с таким логином уже существует!'); nav2('reg.php', 'назад');}			
}else{error('Вы ввели неверное число!'); nav2('reg.php', 'назад');}
}else{error('Слишком длинный или короткий пароль!'); nav2('reg.php', 'назад');}
}else{error('Слишком длинный или короткий e-mail!'); nav2('reg.php', 'назад');}
}else{error('Слишком длинный или короткий логин!'); nav2('reg.php', 'назад');}
}else{error('Вы не заполнили поля!'); nav2('reg.php', 'назад');}
 
break;

}
require("../system/end.php");
?>