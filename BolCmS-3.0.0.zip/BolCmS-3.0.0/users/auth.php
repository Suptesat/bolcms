<?php 
$title = 'Вход';
require("../system/connect_db.php");
require("../system/head.php");
require("../system/functions.php");

switch($_GET['act']){

default:

echo '<div class="phdr">Авторизация</div><div class="bmenu">';
echo '<form action="?act=do" method="post" name="form">';
echo 'Логин:<br/><input name="login" type="text" maxlength="20" /><br/>';
echo 'Пароль:<br/><input name="pass" type="password" maxlength="20" /><br/>';
echo '<input name="submit" type="submit" value="Войти" /></form></div>';
nav();

break;

case 'do':

$login = sec($_POST['login']);
$pass = md5(sec($_POST['pass']));

$user = mysql_fetch_assoc(mysql_query("SELECT (`id`) FROM `users` WHERE `login` = '$login' && `pass` = '$pass'"));
$correct_lp = mysql_result(mysql_query("SELECT COUNT(`id`) FROM `users` WHERE `login` = '$login' && `pass` = '$pass'"), 0);
if($correct_lp > 0){
	$_SESSION['login'] = $login;
	$_SESSION['id'] = $user['id'];
echo '<div class="phdr">Вход</div><div class="bmenu">'.$_SESSION['login'].', добро пожаловать на сайт<br/>';
	echo '<a href="../?">&lt;-- На сайт</a>';
	echo '</div>';
	nav();
}else{
	error('Вы ввели неверный логин или пароль!');
	nav2('auth.php', 'назад');
}

break;

}

require("../system/end.php");
?>