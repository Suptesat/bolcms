<?php 

$title = 'Жизнь сайта';
require("../system/connect_db.php");
require("../system/head.php");
require("../system/functions.php");


echo '<div class="phdr">Информация</div><div class="menu">';
echo '<a href="feedback.php">Обратная связь</a><br/>

<a href="../templates/licenze.php">Лицензия</a><br />
<a href="../public/todes/readme.txt">Реадми BolCmS-3.0.0</a><br />
<a href="../public/todes/HISTORY.TXT">История BolCmS</a><br />
<a href="../templates/faq.php">FAQ</a></div></br>';
echo '</div>';
nav();

require("../system/end.php");
?>