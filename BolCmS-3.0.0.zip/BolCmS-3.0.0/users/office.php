<?php 
$title = 'Мой кабинет';
require("../system/connect_db.php");
require("../system/head.php");
if(empty($_SESSION['login'])){header("location: ../");}
require("../system/functions.php");

switch($_GET['act']){

default:

echo '<div class="phdr">Меню</div>';
echo '<div class="menu"><a href="profile.php?id='.$_SESSION['id'].'">Мой профиль</a></div>';

nav();
break;

case 'exit':

unset($_SESSION['id']);
unset($_SESSION['login']);
info('Вы вышли заходите ещё');
nav();

break;

}

require("../system/end.php");
?>