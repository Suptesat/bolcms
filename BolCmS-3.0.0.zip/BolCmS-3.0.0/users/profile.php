<?php 

$title = 'Профиль пользователя';
require("../system/connect_db.php");
require("../system/head.php");
require("../system/functions.php");

$id = intval($_REQUEST['id']);

$result = mysql_query("SELECT COUNT(`id`) FROM `users` WHERE `id` = '$id'");
$user = mysql_fetch_assoc(mysql_query("SELECT * FROM `users` WHERE `id` = '$id'"));
if(isset($user['id'])){
echo '<div class="phdr">'.$user['login'].'</div><div class="menu">';
echo 'Логин: <li><b>'. $user['login'].'<br></b>';
echo 'E-mail: <li><b>'.$user['mail'].'</b><br>';
echo 'Регистрация: <li><b>'.date('d.m.Y', $user['reg_time']).'</b><br/><br>';
	echo '</div>';
}else{
	error('Такого пользователя не существует!');
	echo '';
}
if ($_GET['mod']=='profile')  {
    echo'<font color="red">Данная Функция в разработке<br></font><br>';
	echo'</div>';
}
else{
}			 
nav();

require("../system/end.php");
?>