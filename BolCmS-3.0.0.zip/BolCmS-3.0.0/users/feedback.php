<?php 

$title = 'Обратная связь';
require("../system/connect_db.php");
require("../system/head.php");
require("../system/functions.php");


if(!empty($config['feedback'])){
echo '<div class="phdr">Контакты, связь</div><div class="bmenu">'.nl2br($config['feedback']).'</div>';
}else{
echo '<div class="phdr">Контакты, связь</div><div class="bmenu">Данные закрыты</div>';
}
echo '<div class="phdr"></div><div class="bmenu"><a href="../">На главную</a></div>';

require("../system/end.php");
?>