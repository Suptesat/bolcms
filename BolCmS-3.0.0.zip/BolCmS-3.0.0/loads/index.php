<?php
$title = 'Загруз-центр';
require("../system/connect_db.php");
require("../system/head.php");
require("../system/functions.php");


switch($_GET['act']){

default:

echo '<div class="phdr">Разделы</div><div class="bmenu">';

$result = mysql_query("SELECT * FROM `loads_cats`");
$cat = mysql_fetch_assoc($result);

if($cat > 0){
 do
 {
 printf('<a href="?act=cat_view&amp;id=%s">%s</a><br/>', $cat['id'], $cat['name']);
 }
 while($cat = mysql_fetch_assoc($result));
}else{
 echo 'Разделов еще нет';
}

echo '</div>';
nav();

break;

case 'cat_view':

$id = intval($_REQUEST['id']);

$cat = mysql_fetch_assoc(mysql_query("SELECT * FROM `loads_cats` WHERE `id` = '$id'"));
echo '<div class="phdr">'.$cat['name'].'</div><div class="bmenu">';

$result = mysql_query("SELECT * FROM `loads` WHERE `id_cat` = '$id' ORDER BY `time` DESC");
$file = mysql_fetch_assoc($result);

if($file > 0){
 do
 {
 printf('<a href="index.php?act=file_view&amp;id=%s">%s</a> (%s)<br/>', $file['id'], $file['name'], date('d.m.y / H:i', $file['time']));
 }
 while($file = mysql_fetch_assoc($result));
}else{
 echo 'Файлов в этом разделе еще нет';
}

echo '</div><div class="phdr"></div><div class="bmenu"><a href="./">Назад</a><br/><a href="../">На главную</a></div>';

break;
case 'file_view':

$id = intval($_REQUEST['id']);

$result = mysql_query("SELECT * FROM `loads` WHERE `id` = '$id'");
$file = mysql_fetch_assoc($result);

if(isset($file['id'])){
echo '<div class="bmenu">'.$file['name'].'</div><div class="bmenu">'.nl2br($file['desc']).'<br/><br/>Автор: '.$file['authour'].' (http://'.$file['site'].')<br/>Размещено: '.date('d.m.y / H:i', $file['time']).'<br/><a href="files/'.$file['file'].'">Скачать '.$file['name'].'</a></div>';
	nav2('./', 'назад');
}else{
	error('Этого файла не существует!');
	nav2('./', 'назад');
}

break;

}

require("../system/end.php");
?>