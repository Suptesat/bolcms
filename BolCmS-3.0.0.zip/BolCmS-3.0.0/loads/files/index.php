<?php 
header("location: ../../");
?>