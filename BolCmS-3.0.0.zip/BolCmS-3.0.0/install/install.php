<?php 

require("../system/connect_db.php");

echo '<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">';
echo '<html>';
echo '<head>';
echo '<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />';
echo '<title>Установка - BolCmS-3.0.0</title>';
echo '<link href="../theme/default.css" rel="stylesheet" type="text/css" />';
echo '</head>';
echo '<body>';

$sql = array();

$sql[] = "CREATE TABLE `book` (
  `id` int(5) NOT NULL auto_increment,
  `login` varchar(20) default NULL,
  `text` varchar(100) NOT NULL,
  `time` varchar(10) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=1 DEFAULT CHARSET=utf8 AUTO_INCREMENT=1";

$sql[] = "CREATE TABLE `config` (
  `id` int(1) NOT NULL auto_increment,
  `style` varchar(50) NOT NULL,
  `title` varchar(50) NOT NULL,
  `desc` varchar(50) NOT NULL,
  `onpage` int(2) NOT NULL,
  `feedback` text NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 AUTO_INCREMENT=2";

$sql[] = "INSERT INTO `config` VALUES (1, 'default', 'BolCmS ver 3.0.0')";

$sql[] = "CREATE TABLE `forum_cats` (
  `id` int(3) NOT NULL auto_increment,
  `name` varchar(50) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 AUTO_INCREMENT=2";

$sql[] = "INSERT INTO `forum_cats` VALUES (1, 'Общение')";

$sql[] = "CREATE TABLE `forum_msg` (
  `id` int(6) NOT NULL auto_increment,
  `id_cat` int(3) NOT NULL,
  `id_topic` int(5) NOT NULL,
  `text` text NOT NULL,
  `authour` varchar(20) NOT NULL,
  `time` varchar(10) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=1 DEFAULT CHARSET=utf8 AUTO_INCREMENT=1";

$sql[] = "CREATE TABLE `forum_topics` (
  `id` int(5) NOT NULL auto_increment,
  `id_cat` int(3) NOT NULL,
  `title` varchar(25) default NULL,
  `text` text,
  `authour` varchar(20) NOT NULL,
  `time` varchar(10) NOT NULL,
  `closed` int(1) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 AUTO_INCREMENT=2";



$sql[] = "CREATE TABLE `library` (
  `id` int(5) NOT NULL auto_increment,
  `id_cat` int(5) NOT NULL,
  `title` varchar(50) NOT NULL,
  `text` text NOT NULL,
  `authour` varchar(50) NOT NULL,
  `time` varchar(10) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=1 DEFAULT CHARSET=utf8 AUTO_INCREMENT=1";

$sql[] = "CREATE TABLE `library_cats` (
  `id` int(5) NOT NULL auto_increment,
  `name` varchar(50) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=1 DEFAULT CHARSET=utf8 AUTO_INCREMENT=1";

$sql[] = "CREATE TABLE `loads` (
  `id` int(5) NOT NULL auto_increment,
  `id_cat` int(3) NOT NULL,
  `name` varchar(50) NOT NULL,
  `desc` text NOT NULL,
  `authour` varchar(50) NOT NULL,
  `site` varchar(50) NOT NULL,
  `file` varchar(50) NOT NULL,
  `time` varchar(10) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=1 DEFAULT CHARSET=utf8 AUTO_INCREMENT=1";

$sql[] = "CREATE TABLE `loads_cats` (
  `id` int(3) NOT NULL auto_increment,
  `name` varchar(50) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=1 DEFAULT CHARSET=utf8 AUTO_INCREMENT=1";

$sql[] = "CREATE TABLE `news` (
  `id` int(5) NOT NULL auto_increment,
  `title` varchar(50) NOT NULL,
  `time` varchar(10) NOT NULL,
  `text` text,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 AUTO_INCREMENT=2";

$sql[] = "INSERT INTO `news` VALUES (1, 'BolCmS ver 3.0.0', '1482760847', 'Движок BolCmS ver 3.0.0 успешно установлен :) ')";

$sql[] = "CREATE TABLE `users` (
  `id` int(5) NOT NULL auto_increment,
  `login` varchar(20) default NULL,
  `mail` varchar(20) NOT NULL,
  `pass` varchar(35) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=1 DEFAULT CHARSET=utf8 AUTO_INCREMENT=1";

$sql[] = "ALTER TABLE `users` ADD `reg_time` VARCHAR( 10 ) NOT NULL AFTER `pass`";


$errormsg = '';

for( $i = 0; $i < count($sql); $i++ )
{
	if( !$result = mysql_query($sql[$i]) )
	{
		$error = mysql_error();
		$errorsql = true;
		$errormsg .= $error['message'].'<br/>';
	}
	else
	{
		$errorsql = false;
	}
}

echo '<div class="phdr">BolCmS ver 3.0.0</div><div class="bmenu">Установка.Инструкции:</div><div class="bmenu">';

echo'<div class="menu"><li>1.Пропишите параметры базы даеных в файле system/connect_db.php</div>';
echo'<div class="menu"><li>2.После этого перейдите по install/index.php и установите сайт</div>';
echo'<div class="menu"><li>3.Зарегистрируйте админа.</div>';
if(!$errorsql){
echo 'Движок успешно установлен! Удалите папку install и пользуйтесь! :)';
}else{
echo '<div class="rmenu">Ошибка! Неверные параметры в system/connect_db.php или вы уже установили движок!</div>';
}

echo '</div><div class="phdr"></div><div class="bmenu"><a href="../">На главную</a></div>';
echo '<div class="rmenu"> by <a href="http://bolcms.cf">BolCmS ver 2.0.0 </a></div>';
?>