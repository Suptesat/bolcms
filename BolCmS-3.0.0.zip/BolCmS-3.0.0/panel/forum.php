<?php
$title = 'Админка';
require("../system/connect_db.php");
require("../system/head.php");
if($_SESSION['id'] != '1'){header("location: ../"); exit();}
require("../system/functions.php");

switch($_GET['act']){

default:

echo '<div class="phdr">Разделы</div><div class="bmenu">';

$result = mysql_query("SELECT * FROM `forum_cats`");
$row = mysql_fetch_assoc($result);

if($row > 0){
 do
 {
printf('<a href="../forum/index.php?act=cat_view&amp;id=%s">%s</a> (<a href="?act=cat_edit&amp;id=%s">Изменить</a>/<a href="?act=cat_del&amp;id=%s">Удалить</a>)<br/>', $row['id'], $row['name'], $row['id'], $row['id']);
 }
 while($row = mysql_fetch_assoc($result));
}else{
 echo 'Разделов пока нет<br/>';
}

echo '<br/><form action="?act=cat_added" method="post" name="form">';
echo '<input name="name" type="text" maxlength="50"><br/>';
echo '<input name="submit" type="submit" value="Добавить"></form></div>';
echo '<div class="phdr"></div><div class="bmenu"><a href="./">Назад в панель</a><br/><a href="../">На главную</a></div>';

break;

case 'cat_added':

if(!empty($_POST['name'])){
 $name = sec($_POST['name']);
 
 mysql_query("INSERT INTO `forum_cats`(`name`) VALUES('$name')");
 info('Раздел успешно добавлен!');
 nav2('forum.php', 'назад');
}else{
 error('Вы не заполнили поле!');
 nav2('forum.php', 'назад');
}

break;

case 'cat_edit':

$id = intval($_REQUEST['id']);

$row = mysql_fetch_assoc(mysql_query("SELECT * FROM `forum_cats` WHERE `id` = '$id'"));

echo '<div class="phdr">Редактировать раздел</div><div class="bmenu">';
echo '<form action="?act=cat_edited&amp;id='.$id.'" method="post" name="form">';
echo 'Название:<br/><input name="name" type="text" maxlength="50" value="'.$row['name'].'" /><br/>';
echo '<input name="submit" type="submit" value="Редактировать" /></form></div>';
nav2('forum.php', 'назад');

break;
case 'cat_edited':

$id = intval($_REQUEST['id']);

if(!empty($_POST['name'])){
 $name = sec($_POST['name']);
 
 mysql_query("UPDATE `forum_cats` SET `name` = '$name' WHERE `id` = '$id'");
 info('Раздел успешно отредактирован!');
 nav2('forum.php', 'назад');
}else{
 error('Вы не заполнили поле!');
 nav2('?act=cat_edit&amp;id='.$id.'', 'назад');
}

break;

case 'cat_del':

$id = intval($_REQUEST['id']);

$result = mysql_query("DELETE FROM `forum_cats` WHERE `id` = '$id'");
if($result == true){
 info('Раздел успешно удален!');
 nav2('forum.php', 'назад');
}else{
 error('Раздел не удален!');
 nav2('forum.php', 'назад');
}

break;

case 'msg_del':

$topic_id = intval($_REQUEST['topic_id']);
$id = intval($_REQUEST['id']);

$result = mysql_query("DELETE FROM `forum_msg` WHERE `id` = '$id'");
if($result == true){
 info('Сообщение успешно удалено!');
 nav2('../forum/topic.php?id='.$topic_id.'', 'назад');
}

break;
case 'topic_del':

$id = intval($_REQUEST['id']);

$result = mysql_query("DELETE FROM `forum_topics` WHERE `id` = '$id'");
$result2 = mysql_query("DELETE FROM `forum_msg` WHERE `id_topic` = '$id'");

info('Тема успешно удалена!');
nav2('../forum/', 'форум');

break;

}

require("../system/end.php");
?>