<?php 
$title = 'Админка';
require("../system/connect_db.php");
require("../system/head.php");
if($_SESSION['id'] != '1'){header("location: ../"); exit();}
require("../system/functions.php");

echo '<div class="phdr">Админка</div>';

switch($_GET['act']){

default:

echo '<div class="bmenu">Настройки</div><div class="bmenu">';
echo '<form action="system.php?act=edited" method="post" name="form">';
echo 'Стиль сайта:<br/><input name="style" type="text" maxlength="50" value="'.$config['style'].'"><br/>';
echo 'Заголовок:<br/><input name="title" type="text" value="'.$config['title'].'" maxlength="50" /><br/>';
echo 'Описание:<br/><input name="desc" type="text" value="'.$config['desc'].'" maxlength="50" /><br/>';
echo 'Копирайт:<br/><input name="copy" type="text" value="BolCmS" maxlength="50" readonly="true" /><br/>';
echo 'Адрес копирайта:<br/><input name="copylink" type="text" value="'.$config['copylink'].'" maxlength="50" readonly="true" /><br/>';
echo 'Элементов на страницу:<br/><input name="onpage" type="text" value="'.$config['onpage'].'" maxlength="50" /><br/>';
echo 'Обратная связь:<br/><textarea name="feedback" cols="" rows="5">'.$config['feedback'].'</textarea><br/>';
echo '<input name="submit" type="submit" value="Сохранить" /></form></div>';
echo '<div class="phdr"></div><div class="phdr"><a href="./">Назад в панель</a><br/><a href="../">На главную</a></div>';

break;
case 'edited':

if(!empty($_POST['style']) && !empty($_POST['title']) && !empty($_POST['desc']) && !empty($_POST['copy']) && !empty($_POST['copylink']) && !empty($_POST['onpage'])){
 $style = sec($_POST['style']);
 $title = sec($_POST['title']);
 $desc = sec($_POST['desc']);
 $copy = sec($_POST['copy']);
 $copylink = sec($_POST['copylink']);
 $onpage = sec($_POST['onpage']);
 $feedback = sec($_POST['feedback']);
 
 mysql_query("UPDATE `config` SET `style` = '$style', `title` = '$title', `desc` = '$desc', `copy` = 'StrikeCMS', `copylink` = '$copylink', `onpage` = '$onpage', `feedback` = '$feedback' WHERE `id` = '1'");
echo '<div class="phdr">Информация</div><div class="bmenu">Настройки успешно сохранены!</div>';
echo '<div class="phdr"></div><div class="phdr"><a href="./">Назад в панель</a><br/><a href="../">На главную</a></div>';
}else{
echo '<div class="phdr">Информация</div><div class="bmenu">Вы не заполнили поля!</div>';
echo '<div class="phdr"></div><div class="phdr"><a href="system.php">Назад</a><br/><a href="../">На главную</a></div>';
}

break;
}

require("../system/end.php");
?>