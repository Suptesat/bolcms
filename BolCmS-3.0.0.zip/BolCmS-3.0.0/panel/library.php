<?php
$title = 'Админка';
require("../system/connect_db.php");
require("../system/head.php");
if($_SESSION['id'] != '1'){header("location: ../"); exit();}
require("../system/functions.php");

echo '<div class="phdr">Библиотека</div>';

switch($_GET['act']){

default:

echo '<div class="bmenu">Разделы</div><div class="bmenu">';

$result = mysql_query("SELECT * FROM `library_cats`");
$row = mysql_fetch_assoc($result);

if($row > 0){
 do
 {
 printf('<a href="library.php?act=cat_view&amp;id=%s">%s</a> (<a href="?act=cat_edit&amp;id=%s">edit</a>/<a href="?act=cat_del&amp;id=%s">del</a>)<br/>', $row['id'], $row['name'], $row['id'], $row['id']);
 }
 while($row = mysql_fetch_assoc($result));
}else{
 echo 'Разделов пока нет<br/>';
}

echo '<br/><form action="?act=cat_added" method="post" name="form">';
echo '<input name="name" type="text" maxlength="50"><br/>';
echo '<input name="submit" type="submit" value="Добавить"></form></div>';
echo '<div class="phdr"></div><div class="phdr"><a href="./">Назад в панель</a><br/><a href="../">На главную</a></div>';

break;

case 'cat_added':

if(!empty($_POST['name'])){
 $name = sec($_POST['name']);
 
 mysql_query("INSERT INTO `library_cats`(`name`) VALUES('$name')");
echo '<div class="phdr">Информация</div><div class="bmenu">Раздел успешно добавлен!</div>';
echo '<div class="phdr"></div><div class="phdr"><a href="library.php">Назад</a><br/><a href="../">На главную</a></div>';
}else{
echo '<div class="bmenu">Ошибка!</div><div class="bmenu">Вы не заполнили поле!</div>';
echo '<div class="phdr"></div><div class="phdr"><a href="library.php">Назад</a><br/><a href="../">На главную</a></div>';
}

break;

##                      Форма редактирования раздела                         ##
case 'cat_edit':

$id = intval($_REQUEST['id']);

$row = mysql_fetch_assoc(mysql_query("SELECT * FROM `library_cats` WHERE `id` = '$id'"));

echo '<div class="bmenu">Редактировать раздел</div><div class="bmenu">';
echo '<form action="?act=cat_edited&amp;id='.$id.'" method="post" name="form">';
echo 'Название:<br/><input name="name" type="text" maxlength="50" value="'.$row['name'].'" /><br/>';
echo '<input name="submit" type="submit" value="Редактировать" /></form></div>';
echo '<div class="phdr"></div><div class="phdr"><a href="library.php">Назад</a><br/><a href="../">На главную</a></div>';

break;


case 'cat_edited':

$id = intval($_REQUEST['id']);

if(!empty($_POST['name'])){
 $name = sec($_POST['name']);
 
 mysql_query("UPDATE `library_cats` SET `name` = '$name' WHERE `id` = '$id'");
echo '<div class="phdr">Информация</div><div class="bmenu">Раздел успешно отредактирован!</div>';
echo '<div class="phdr"></div><div class="phdr"><a href="library.php">Назад</a><br/><a href="../">На главную</a></div>';
}else{
 echo '<div class="s1">Ошибка!</div><div class="s2">Вы не заполнили поле!</div>';
 echo '<div class="s1">Навигация</div><div class="s2"><a href="library.php?act=cat_edit&amp;id='.$id.'">назад</a><br/><a href="../">на главную</a></div>';
}

break;

case 'cat_del':

$id = intval($_REQUEST['id']);

$result = mysql_query("DELETE FROM `library_cats` WHERE `id` = '$id'");
if($result == true){
 echo '<div class="s1">Информация</div><div class="s2">Раздел успешно удален!</div>';
 echo '<div class="s1">Навигация</div><div class="s2"><a href="library.php">назад</a><br/><a href="../">на главную</a></div>';
}else{
 echo '<div class="s1">Ошибка!</div><div class="s2">Раздел не удален!</div>';
 echo '<div class="s1">Навигация</div><div class="s2"><a href="library.php">назад</a><br/><a href="../">на главную</a></div>';
}

break;

case 'cat_view':

$id = intval($_REQUEST['id']);

$cat = mysql_fetch_assoc(mysql_query("SELECT * FROM `library_cats` WHERE `id` = '$id'"));
echo '<div class="s1">'.$cat['name'].'</div><div class="s2">';

$result = mysql_query("SELECT * FROM `library` WHERE `id_cat` = '$id' ORDER BY `time` DESC");
$row = mysql_fetch_assoc($result);

if($row > 0){
 do
 {
 printf('<a href="../library/index.php?act=story_view&amp;id=%s">%s</a> (<a href="?act=story_edit&amp;&amp;cat=%s&amp;id=%s">edit</a>/<a href="?act=story_del&amp;cat=%s&amp;id=%s">del</a>)<br/>', $row['id'], $row['title'], $id, $row['id'], $id, $row['id']);
 }
 while($row = mysql_fetch_assoc($result));
}else{
 echo 'Рассказов пока нет в этом разделе<br/>';
}

echo '<br/><a href="library.php?act=story_add&amp;id='.$id.'" class="button">Добавить рассказ</a></div>';
echo '<div class="s1">Навигация</div><div class="s2"><a href="library.php">назад</a><br/><a href="../">на главную</a></div>';

break;
case 'story_add':

$id = intval($_REQUEST['id']);

echo '<div class="s1">Добавить рассказ</div><div class="s2">';
echo '<form action="?act=story_added&amp;id='.$id.'" method="post" name="form">';
echo 'Заголовок:<br/><input name="title" type="text" maxlength="50"><br/>';
echo 'Текст:<br/><textarea name="text" rows="5"></textarea><br/>';
echo 'Автор:<br/><input name="authour" type="text" maxlength="50"><br/>';
echo '<input name="submit" type="submit" value="Добавить"></form></div>';
echo '<div class="s1">Навигация</div><div class="s2"><a href="library.php?act=cat_view&amp;id='.$id.'">назад</a><br/><a href="../">на главную</a></div>';

break;

case 'story_added':

$id = intval($_REQUEST['id']);

if(!empty($_POST['title']) && !empty($_POST['text']) && !empty($_POST['authour'])){
 $title = sec($_POST['title']);
 $text = sec($_POST['text']);
 $authour = sec($_POST['authour']);
 
 mysql_query("INSERT INTO `library`(`id_cat`, `title`, `text`, `authour`, `time`) VALUES('$id', '$title', '$text', '$authour', '".time()."')") or die(mysql_error());
 echo '<div class="s1">Информация</div><div class="s2">Рассказ успешно добавлен в раздел!</div>';
 echo '<div class="s1">Навигация</div><div class="s2"><a href="library.php?act=cat_view&amp;id='.$id.'">назад</a><br/><a href="../">на главную</a></div>';
}else{
 echo '<div class="s1">Ошибка!</div><div class="s2">Вы не заполнили поля!</div>';
 echo '<div class="s1">Навигация</div><div class="s2"><a href="library.php?act=story_add&amp;id='.$id.'">назад</a><br/><a href="../">на главную</a></div>';
}

break;

case 'story_edit':

$cat = intval($_REQUEST['cat']);
$id = intval($_REQUEST['id']);

$story = mysql_fetch_assoc(mysql_query("SELECT * FROM `library` WHERE `id` = '$id'"));

echo '<div class="s1">Редактировать рассказ</div><div class="s2">';
echo '<form action="?act=story_edited&amp;cat='.$cat.'&amp;id='.$id.'" method="post" name="form">';
echo 'Заголовок:<br/><input name="title" type="text" maxlength="50" value="'.$story['title'].'"><br/>';
echo 'Текст:<br/><textarea name="text" rows="5">'.$story['text'].'</textarea><br/>';
echo 'Автор:<br/><input name="authour" type="text" maxlength="50" value="'.$story['authour'].'"><br/>';
echo '<input name="submit" type="submit" value="Редактировать"></form></div>';
echo '<div class="s1">Навигация</div><div class="s2"><a href="library.php?act=cat_view&amp;id='.$cat.'">назад</a><br/><a href="../">на главную</a></div>';

break;

case 'story_edited':

$cat = intval($_REQUEST['cat']);
$id = intval($_REQUEST['id']);

if(!empty($_POST['title']) && !empty($_POST['text']) && !empty($_POST['authour'])){
 $title = sec($_POST['title']);
 $text = sec($_POST['text']);
 $authour = sec($_POST['authour']);
 
 mysql_query("UPDATE `library` SET `title` = '$title', `text` = '$text', `authour` = '$authour' WHERE `id` = '$id'");
 echo '<div class="s1">Информация</div><div class="s2">Информация о рассказе успешно отредактирована!</div>';
 echo '<div class="s1">Навигация</div><div class="s2"><a href="library.php?act=cat_view&amp;id='.$cat.'">назад</a><br/><a href="../">на главную</a></div>';
}else{
 echo '<div class="s1">Ошибка!</div><div class="s2">Вы не заполнили поля!</div>';
 echo '<div class="s1">Навигация</div><div class="s2"><a href="library.php?act=story_edit&amp;cat='.$cat.'&amp;id='.$id.'">назад</a><br/><a href="../">на главную</a></div>';
}

break;

case 'story_del':

$cat = intval($_REQUEST['cat']);
$id = intval($_REQUEST['id']);

$result = mysql_query("DELETE FROM `library` WHERE `id` = '$id'") or die(mysql_error());
if($result == true){
 echo '<div class="s1">Информация</div><div class="s2">Рассказ успешно удален!</div>';
 echo '<div class="s1">Навигация</div><div class="s2"><a href="library.php?act=cat_view&amp;id='.$cat.'">назад</a><br/><a href="../">на главную</a></div>';
}

break;

}

require("../system/end.php");
?>