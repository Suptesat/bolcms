<?php

$title = 'Админка';
require("../system/connect_db.php");
require("../system/head.php");
if($_SESSION['id'] != '1'){header("location: ../"); exit();}
require("../system/functions.php");


switch($_GET['act']){

default:

echo '<div class="phdr">Список</div><div class="bmenu">';

$count = mysql_result(mysql_query("SELECT COUNT(*) FROM `users`"), 0);
if($count > 0){
	$pages = ceil($count/$config['onpage']);
	$page = abs(intval(@$_REQUEST['page']));
	if($page == 0) $page = 1;
	$from = ($page-1)*$config['onpage'];

	$result = mysql_query("SELECT * FROM `users` ORDER BY `reg_time` DESC LIMIT $from, ".$config['onpage']."");
	while($user = mysql_fetch_assoc($result)){
		if($user['id'] > 1){
echo '<a href="../users/profile.php?id='.$user['id'].'">'.$user['login'].'</a> (<a href="?act=sure_del&amp;id='.$user['id'].'">(Удалить)</a>)<br/>';
		}
	}
}

echo '</div><div class="phdr"></div><div class="bmenu">';
navig($page, 'index.php?', $pages);
echo '<a href="./">Назад в панель</a><br/><a href="../">На главную</a></div>';

break;



$id = intval($_REQUEST['id']);

$user = mysql_fetch_assoc(mysql_query("SELECT (`login`) FROM `users` WHERE `id` = '$id'"));

echo '<div class="phdr">Подтверждение удаления</div><div class="bmenu">';
echo 'Вы уверены, что хотите удалить пользователя '.$user['login'].'?<br/>';
echo '<form action="?act=del&id='.$id.'" method="post" name="form">';
echo '<input name="del" type="submit" value="Да, удалить" /></form></div>';
nav2('users.php', 'назад');

break;

case 'del':

$id = intval($_REQUEST['id']);

mysql_query("DELETE FROM `users` WHERE `id` = '$id'");
info('Пользователь удален!');
nav2('./', 'назад в панель');

break;
}

require("../system/end.php");
?>