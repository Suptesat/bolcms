<?php
$title = 'Админка';
require("../system/connect_db.php");
require("../system/head.php");
if($_SESSION['id'] != '1'){header("location: ../"); exit();}
require("../system/functions.php");


switch($_GET['act']){

default:

echo '<div class="phdr">Загрузки</div><div class="bmenu">';

$result = mysql_query("SELECT * FROM `loads_cats`");
$row = mysql_fetch_assoc($result);

if($row > 0){
 do
 {
printf('<a href="?act=cat_view&amp;id=%s">%s</a> (<a href="?act=cat_edit&amp;id=%s">Изменить</a>/<a href="?act=cat_del&amp;id=%s">Удалить</a>)<br/>', $row['id'], $row['name'], $row['id'], $row['id']);
 }
 while($row = mysql_fetch_assoc($result));
}else{
 echo 'Разделов пока нет<br/>';
}

echo '<br/><form action="?act=cat_added" method="post" name="form">';
echo '<input name="name" type="text" maxlength="50"><br/>';
echo '<input name="submit" type="submit" value="Добавить"></form></div>';
echo '<div class="phdr"></div><div class="bmenu"><a href="./">Назад в панель</a><br/><a href="../">На главную</a></div>';

break;

case 'cat_added':

if(!empty($_POST['name'])){
 $name = sec($_POST['name']);
 
 mysql_query("INSERT INTO `loads_cats`(`name`) VALUES('$name')");
echo '<div class="phdr">Информация</div><div class="rmenu">Раздел успешно добавлен!</div>';
echo '<div class="phdr"></div><div class="bmenu"><a href="loads.php">Назад</a><br/><a href="../">На главную</a></div>';
}else{
echo '<div class="phdr">Ошибка!</div><div class="rmenu">Вы не заполнили поле!</div>';
echo '<div class="phdr"><a href="loads.php">Назад</a><br/><a href="../">На главную</a></div>';
}

break;

case 'cat_edit':

$id = intval($_REQUEST['id']);

$row = mysql_fetch_assoc(mysql_query("SELECT * FROM `loads_cats` WHERE `id` = '$id'"));

echo '<div class="phdr">Редактировать раздел</div><div class="bmenu">';
echo '<form action="?act=cat_edited&amp;id='.$id.'" method="post" name="form">';
echo 'Название:<br/><input name="name" type="text" maxlength="50" value="'.$row['name'].'" /><br/>';
echo '<input name="submit" type="submit" value="Редактировать" /></form></div>';
echo '<div class="phdr"><a href="loads.php">Назад</a><br/><a href="../">На главную</a></div>';

break;

case 'cat_edited':

$id = intval($_REQUEST['id']);

if(!empty($_POST['name'])){
 $name = sec($_POST['name']);
 
 mysql_query("UPDATE `loads_cats` SET `name` = '$name' WHERE `id` = '$id'");
echo '<div class="phdr">Информация</div><div class="rmenu">Раздел успешно отредактирован!</div>';
echo '<div class="phdr"><a href="loads.php">Назад</a><br/><a href="../">На главную</a></div>';
}else{
echo '<div class="phdr">Ошибка!</div><div class="rmenu">Вы не заполнили поле!</div>';
echo '<div class="phdr"><a href="loads.php?act=cat_edit&amp;id='.$id.'">Назад</a><br/><a href="../">На главную</a></div>';
}

break;

case 'cat_del':

$id = intval($_REQUEST['id']);

$result = mysql_query("DELETE FROM `loads_cats` WHERE `id` = '$id'");
if($result == true){
echo '<div class="phdr">Информация</div><div class="rmenu">Раздел успешно удален!</div>';
echo '<div class="phdr"><a href="loads.php">Назад</a><br/><a href="../">На главную</a></div>';
}else{
echo '<div class="phdr">Ошибка!</div><div class="rmenu">Раздел не удален!</div>';
echo '<div class="phdr"><a href="loads.php">Назад</a><br/><a href="../">На главную</a></div>';
}

break;

case 'cat_view':

$id = intval($_REQUEST['id']);

// вывод названия раздела
$cat = mysql_fetch_assoc(mysql_query("SELECT * FROM `loads_cats` WHERE `id` = '$id'"));
echo '<div class="phdr">'.$cat['name'].'</div><div class="bmenu">';

// вывод файлов
$result = mysql_query("SELECT * FROM `loads` WHERE `id_cat` = '$id' ORDER BY `time` DESC");
$row = mysql_fetch_assoc($result);

if($row > 0){
 do
 {
printf('<a href="../loads/index.php?act=file_view&amp;id=%s">%s</a> (<a href="?act=file_edit&amp;&amp;cat=%s&amp;id=%s">Изменить</a>/<a href="?act=file_del&amp;cat=%s&amp;id=%s">Удалить</a>)<br/>', $row['id'], $row['name'], $id, $row['id'], $id, $row['id']);
 }
 while($row = mysql_fetch_assoc($result));
}else{
 echo 'Файлов в этом разделе нет<br/>';
}

echo '<br/><a href="loads.php?act=file_add&amp;id='.$id.'" class="button">Добавить файл</a></div>';
echo '<div class="s1">Навигация</div><div class="s2"><a href="loads.php">назад</a><br/><a href="../">на главную</a></div>';

break;

case 'file_add':

$id = intval($_REQUEST['id']);

echo '<div class="s1">Добавить файл</div><div class="s2">';
echo '<form action="?act=file_added&amp;id='.$id.'" method="post" enctype="multipart/form-data" name="form">';
echo 'Название:*<br/><input name="name" type="text" maxlength="50"><br/>';
echo 'Описание:*<br/><textarea name="desc" rows="5"></textarea><br/>';
echo 'Автор:<br/><input name="authour" type="text" maxlength="50"><br/>';
echo 'Сайт автора:<br/><input name="site" type="text" maxlength="50"><br/>';
echo 'Выбрать файл:*<br/><input name="file" type="file"><br/>';
echo '<input name="submit" type="submit" value="Добавить"></form></div>';
echo '<div class="s1">Навигация</div><div class="s2"><a href="loads.php?act=cat_view&amp;id='.$id.'">назад</a><br/><a href="../">на главную</a></div>';

break;


case 'file_added':

$id = intval($_REQUEST['id']);

if(!empty($_POST['name']) && !empty($_POST['desc']) && !empty($_FILES['file'])){
 $name = sec($_POST['name']);
 $desc = sec($_POST['desc']);
 $authour = sec($_POST['authour']);
 $site = sec($_POST['site']);
 $file = sec($_FILES['file']['name']);
 
 mysql_query("INSERT INTO `loads`(`id_cat`, `name`, `desc`, `authour`, `site`, `file`, `time`) VALUES('$id', '$name', '$desc', '$authour', '$site', '$file', '".time()."')") or die(mysql_error());
 copy($_FILES['file']['tmp_name'], '../loads/files/'.$file);
 echo '<div class="s1">Информация</div><div class="s2">Файл успешно добавлен в раздел!</div>';
 echo '<div class="s1">Навигация</div><div class="s2"><a href="loads.php?act=cat_view&amp;id='.$id.'">назад</a><br/><a href="../">на главную</a></div>';
}else{
 echo '<div class="s1">Ошибка!</div><div class="s2">Вы не заполнили важные поля!</div>';
 echo '<div class="s1">Навигация</div><div class="s2"><a href="loads.php?act=file_add&amp;id='.$id.'">назад</a><br/><a href="../">на главную</a></div>';
}

break;

case 'file_edit':

$cat = intval($_REQUEST['cat']);
$id = intval($_REQUEST['id']);

$file = mysql_fetch_assoc(mysql_query("SELECT * FROM `loads` WHERE `id` = '$id'"));

echo '<div class="s1">Редактировать файл</div><div class="s2">';
echo '<form action="?act=file_edited&amp;cat='.$cat.'&amp;id='.$id.'" method="post" name="form">';
echo 'Название:*<br/><input name="name" type="text" maxlength="50" value="'.$file['name'].'"><br/>';
echo 'Описание:*<br/><textarea name="desc" rows="5">'.$file['desc'].'</textarea><br/>';
echo 'Автор:<br/><input name="authour" type="text" maxlength="50" value="'.$file['authour'].'"><br/>';
echo 'Сайт автора:<br/><input name="site" type="text" maxlength="50" value="'.$file['site'].'"><br/>';
echo '<input name="submit" type="submit" value="Редактировать"></form></div>';
echo '<div class="s1">Навигация</div><div class="s2"><a href="loads.php?act=cat_view&amp;id='.$cat.'">назад</a><br/><a href="../">на главную</a></div>';

break;

case 'file_edited':

$cat = intval($_REQUEST['cat']);
$id = intval($_REQUEST['id']);

if(!empty($_POST['name']) && !empty($_POST['desc'])){
 $name = sec($_POST['name']);
 $desc = sec($_POST['desc']);
 $authour = sec($_POST['authour']);
 $site = sec($_POST['site']);
 
 mysql_query("UPDATE `loads` SET `name` = '$name', `desc` = '$desc', `authour` = '$authour', `site` = '$site' WHERE `id` = '$id'");
 echo '<div class="s1">Информация</div><div class="s2">Информация о файле успешно отредактирована!</div>';
 echo '<div class="s1">Навигация</div><div class="s2"><a href="loads.php?act=cat_view&amp;id='.$cat.'">назад</a><br/><a href="../">на главную</a></div>';
}else{
 echo '<div class="s1">Ошибка!</div><div class="s2">Вы не заполнили важные поля!</div>';
 echo '<div class="s1">Навигация</div><div class="s2"><a href="loads.php?act=file_edit&amp;cat='.$cat.'&amp;id='.$id.'">назад</a><br/><a href="../">на главную</a></div>';
}

break;


case 'file_del':

$cat = intval($_REQUEST['cat']);
$id = intval($_REQUEST['id']);

$result = mysql_query("DELETE FROM `loads` WHERE `id` = '$id'") or die(mysql_error());
if($result == true){
 echo '<div class="s1">Информация</div><div class="s2">Файл успешно удален!</div>';
 echo '<div class="s1">Навигация</div><div class="s2"><a href="loads.php?act=cat_view&amp;id='.$cat.'">назад</a><br/><a href="../">на главную</a></div>';
}

break;

}

require("../system/end.php");
?>