<?php 

$title = 'Админка';
require("../system/connect_db.php");
require("../system/head.php");
require("../system/functions.php");


switch($_GET['act']){

default:

echo '<div class="phdr">Управление сайтом</div><div class="menu">';

$library = mysql_result(mysql_query("SELECT count(*) FROM `library`"), 0); // кол-о статей в библиотеке
$loads = mysql_result(mysql_query("SELECT count(*) FROM `loads`"), 0); // кол-о статей в библиотеке
$forum_topics = mysql_result(mysql_query("SELECT count(*) FROM `forum_topics`"), 0); // кол-о тем в форуме
$forum_msg = mysql_result(mysql_query("SELECT count(*) FROM `forum_msg`"), 0); // кол-о сообщений в форуме
$users = mysql_result(mysql_query("SELECT count(*) FROM `users`"), 0); // кол-о пользователей

echo '<div class="menu"><a href="library.php"><li>Библиотека</a> ('.$library.')</div>';
echo '<div class="menu"><a href="loads.php"><li>Загрузки</a> ('.$loads.')</div>';
echo '<div class="menu"><a href="forum.php"><li>Форум</a> ('.$forum_topics.'/'.$forum_msg.')</div>';

// новости сайта
$news = mysql_fetch_assoc(mysql_query("SELECT * FROM `news` ORDER BY `time` DESC LIMIT 1"));
if(!isset($news['time'])){echo '<div class="menu"><a href="news.php"><li>Новости</a> (Новостей пока нет)</div>';
}else{
echo '<div class="menu"><a href="news.php"><li>Новости</a> ('.date('d.m.Y / H:i', $news['time']).')</div>';
}

echo '<div class="menu"><a href="users.php"><li>Пользователи</a> ('.$users.')</div>';
echo '<div class="menu"><a href="system.php"><li>Настройки сайта</a></div>';

echo '</div><div class="border"><a href="../">На главную</a></div>';

break;
case 'exit':

unset($_SESSION['adm']);
echo '<div class="bmenu">Информация</div><div class="bmenu">Вы успешно вышли!</div>';
echo '<div class="bmenu"><a href="../">На главную</a></div>';

break;

}

require("../system/end.php");
?>