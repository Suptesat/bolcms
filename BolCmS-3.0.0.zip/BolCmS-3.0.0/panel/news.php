<?php

$title = 'Админка';
require("../system/connect_db.php");
require("../system/head.php");
if($_SESSION['id'] != '1'){header("location: ../"); exit();}
require("../system/functions.php");


switch($_GET['act']){


default:

echo '<div class="phdr">Список</div><div class="bmenu">';

$result = mysql_query("SELECT * FROM `news` ORDER BY `time` DESC");
$row = mysql_fetch_assoc($result);

if($row > 0){
 do
 {
printf('<a href="../str/news.php?act=view&amp;id=%s">%s</a> от %s (<a href="?act=edit&amp;id=%s">Изменить</a>/<a href="?act=del&amp;id=%s">Удалить</a>)<br/>', $row['id'], $row['title'], date('d.m.Y / H:i', $row['time']), $row['id'], $row['id']);
 }
 while($row = mysql_fetch_assoc($result));
}else{
 echo 'Новостей пока нет<br/>';
}

echo '<br/><a href="?act=add" class="button">Добавить новость</a></div>';
echo '<div class="gmenu"><a href="./">Назад в панель</a><br/><a href="../">На главную</a></div>';

break;
case 'add':

echo '<div class="phdr">Добавить новость</div><div class="menu">';
echo '<form action="?act=added" method="post" name="form">';
echo 'Заголовок:<br/><input name="title" type="text" maxlength="50" /><br/>';
echo 'Текст:<br/><textarea name="text" rows="5"></textarea><br/>';
echo '<input name="submit" type="submit" value="Добавить" /></form></div>';
echo '<div class="gmenu"><a href="news.php">Назад</a><br/><a href="../">На главную</a></div>';

break;

case 'added':

if(!empty($_POST['title']) && !empty($_POST['text'])){
 $title = sec($_POST['title']);
 $text = sec($_POST['text']);
 
 mysql_query("INSERT INTO `news`(`title`,`text`,`time`) VALUES('$title', '$text', '".time()."')");
echo '<div class="phdr">Информация</div><div class="menu">Новость успешно добавлена</div>';
echo '<div class="phdr"><a href="news.php">Назад</a><br/><a href="../">На главную</a></div>';
}else{
echo '<div class="phdr">Ошибка!</div><div class="rmenu">Вы не заполнили одно из полей!</div>';
echo '<div class="phdr"><a href="news.php?act=add">Назад</a><br/><a href="../">На главную</a></div>';
}

break;

case 'edit':

$id = intval($_REQUEST['id']);

$row = mysql_fetch_assoc(mysql_query("SELECT * FROM `news` WHERE `id` = '$id'"));

echo '<div class="phdr">Редактировать новость</div><div class="menu">';
echo '<form action="?act=edited&amp;id='.$id.'" method="post" name="form">';
echo 'Заголовок:<br/><input name="title" type="text" maxlength="50" value="'.$row['title'].'" /><br/>';
echo 'Текст:<br/><textarea name="text" rows="5">'.$row['text'].'</textarea><br/>';
echo '<input name="submit" type="submit" value="Редактировать" /></form></div>';
echo '<div class="phdr"><a href="news.php">Назад</a><br/><a href="../">На главную</a></div>';

break;

case 'edited':

$id = intval($_REQUEST['id']);

if(!empty($_POST['title']) && !empty($_POST['text'])){
 $title = sec($_POST['title']);
 $text = sec($_POST['text']);
 
 mysql_query("UPDATE `news` SET `title` = '$title', `text` = '$text' WHERE `id` = '$id'");
echo '<div class="phdr">Информация</div><div class="rmenu">Новость успешно отредактирована!</div>';
echo '<div class="phdr"><a href="news.php">Назад</a><br/><a href="../">На главную</a></div>';
}else{
echo '<div class="phdr">Ошибка!</div><div class="rmenu">Вы не заполнили поля!</div>';
echo '<div class="phdr"><a href="news.php">Назад</a><br/><a href="../">На главную</a></div>';
}

break;

case 'del':

$id = intval($_REQUEST['id']);

$result = mysql_query("DELETE FROM `news` WHERE `id` = '$id'");
if($result == true){
echo '<div class="phdr">Информация</div><div class="rmenu">Новость успешно удалена!</div>';
echo '<div class="phdr"><a href="news.php">Назад</a><br/><a href="../">На главную</a></div>';
}else{
echo '<div class="phdr">Ошибка!</div><div class="rmenu">Новость не удалена!</div>';
echo '<div class="phdr"><a href="news.php">Назад</a><br/><a href="../">На главную</a></div>';
}

break;

}

require("../system/end.php");
?>