<?php 
$title = 'Лицензия';
require("../system/connect_db.php");
require("../system/head.php");
require("../system/functions.php");

echo '<div class="phdr">Лицензия</div>';
echo'<div class="menu">05.11.2016 / 23:39
<li>Вы неимеете право распространять движок
как свой продукт. Вы можите делать свои
моды двига указав версию
модифицированого двига. <li>Запрещается
удалять в readme.txt строки описаные об
авторе движка. 
<li>В течении 1 месяца от установки движка на вашем сайте копирайт внизу страниц запрещено снимать.</div>';
nav();

require("../system/end.php");
?>