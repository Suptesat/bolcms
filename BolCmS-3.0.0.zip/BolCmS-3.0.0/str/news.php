<?php 
$title = 'Новости сайта';
require("../system/connect_db.php");
require("../system/head.php");
require("../system/functions.php");


switch($_GET['act']){

default:

echo '<div class="phdr">Список</div><div class="bmenu">';

$result = mysql_query("SELECT * FROM `news` ORDER BY `time` DESC LIMIT 20");
$row = mysql_fetch_assoc($result);

if($row > 0){
 do
 {
printf('<a href="news.php?act=view&amp;id=%s">%s</a> (%s)<br/>', $row['id'], $row['title'], date('d.m.Y / H:i', $row['time']));
 }
 while($row = mysql_fetch_assoc($result));
}else{
 echo 'Новостей пока нет';
}

echo '</div><div class="phdr"></div><div class="bmenu"><a href="../">на главную</a></div>';

break;
case 'view':

$id = sec($_REQUEST['id']);

$row = mysql_fetch_assoc(mysql_query("SELECT * FROM `news` WHERE `id` = '$id'"));

if(isset($row['id'])){
 echo '<div class="phdr">'.$row['title'].'</div><div class="bmenu">'.$row['text'].'<br/><br/><i>Размещено: '.date('d.m.y / H:i', $row['time']).'</i></div>';
echo '<div class="phdr"></div><div class="bmenu"><a href="./news.php">Новости</a><br/><a href="../">На главную</a></div>';
}else{
echo '<div class="phdr">Ошибка!</div><div class="bmenu">Этой новости не существует!</div>';
echo '<div class="phdr"></div><div class="bmenu"><a href="./">Новости</a><br/><a href="../">На главную</a></div>';
}

}

require("../system/end.php");
?>