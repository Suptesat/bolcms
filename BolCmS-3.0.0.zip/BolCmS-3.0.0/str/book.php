<?php 
$title = 'Чат';
require("../system/connect_db.php");
require("../system/head.php");
require("../system/functions.php");


switch($_GET['act']){

default:

echo '<div class="phdr">Чат</div><div class="bmenu">';

$count = mysql_result(mysql_query("SELECT COUNT(*) FROM `book`"), 0);
if($count > 0){
	$pages = ceil($count/$config['onpage']);
	$page = abs(intval(@$_REQUEST['page']));
	if($page == 0) $page = 1;
	$from = ($page-1)*$config['onpage'];

	$result = mysql_query("SELECT * FROM `book` ORDER BY `time` DESC LIMIT $from, ".$config['onpage']."");
	while($msg = mysql_fetch_assoc($result)){
echo '<a href="../str/book.php?act=answer&amp;id='.$msg['id'].'">'.$msg['login'].'</a> <i>'.date('d.m.Y / H:i', $msg['time']).'</i><br/>'.$msg['text'].'<br/>';
	}
}else{
	echo 'Сообщений еще нет<br/>';
}

echo '</div><div class="phdr"></div><div class="border">';
navig($page, '../str/book.php?', $pages);
echo '<div class "border">Добавить сообщение:</div><br/>';
echo '<form action="../str/book.php?act=addmsg" method="post" name="form">';
echo '<textarea name="text" cols="" rows="3"></textarea><br/>';
$_SESSION['captcha'] = rand(1111, 9999);
echo 'Введите число: <b>'.$_SESSION['captcha'].'</b><br/>';
echo '<input name="captcha" type="text" maxlength="4" /><br/>';
echo '<input name="submit" type="submit" value="Написать" /></form><br/></div>';
echo '<div class="border"><a href="../">На главную</a></div>';

break;

case 'addmsg':

if(!empty($_POST['text'])){
if(!empty($_SESSION['login'])){$login = $_SESSION['login'];}else{$login = 'Гость';}
if($_SESSION['captcha'] == sec($_POST['captcha'])){
	$text = sec($_POST['text']);
	
	mysql_query("INSERT INTO `book` SET `login` = '$login', `text` = '$text', `time` = '".time()."'");
echo '<div class="phdr">Информация</div><div class="bmenu">Сообщение успешно добавлено!</div>';
	nav2('./', 'гостевая');
}else{error('Вы не правильно ввели код!'); nav2('./', 'назад');}
}else{error('Вы не заполнли поле!'); nav2('./', 'назад');}

break;

case 'answer':

$id = intval($_REQUEST['id']);

$msg = mysql_fetch_assoc(mysql_query("SELECT * FROM `book` WHERE `id` = '$id'"));
if(isset($msg['id'])){
	echo '<form action="?act=answered&amp;id='.$id.'" method="post" name="form">';
echo '<div class="phdr">Ответ пользователю '.$msg['login'].'</div><div class="bmenu">';
	echo '<textarea name="text" rows="3">'.$msg['login'].', </textarea><br/>';
	$_SESSION['captcha'] = rand(1111, 9999);
	echo 'Введите число: <b>'.$_SESSION['captcha'].'</b><br/>';
	echo '<input name="captcha" type="text" maxlength="4" /><br/>';
	echo '<input name="submit" type="submit" value="Ответить" /></form></div>';
	nav2('./', 'назад');
}else{
	error('Сообщение, на которое вы хотите ответить не существует!');
	nav2('./', 'назад');
}
break;

case 'answered':

$id = intval($_REQUEST['id']);

if(!empty($_POST['text'])){
if($_SESSION['captcha'] == sec($_POST['captcha'])){
	if(empty($_SESSION['login'])){$login = 'Гость';}else{$login = $_SESSION['login'];}
	$text = sec($_POST['text']);
	
	mysql_query("INSERT INTO `book` SET `login` = '$login', `text` = '$text', `time` = '".time()."'");
	info('Ответ пользователю успешно добавлен!');
	nav2('./', 'в гостевую');
}else{error('Вы не правильно ввели код!'); nav2('?act=answer&amp;id='.$id.'', 'назад');}
}else{error('Вы не заполниле поле!'); nav2('?act=answer&amp;id='.$id.'', 'назад');}

break;
	
}

require("../system/end.php");
?>