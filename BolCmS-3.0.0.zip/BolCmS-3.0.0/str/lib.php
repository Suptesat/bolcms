<?php 
$title = 'Библиотека';
require("../system/connect_db.php");
require("../system/head.php");
require("../system/functions.php");


switch($_GET['act']){

default:

echo '<div class="phdr">Разделы</div><div class="bmenu">';

$stories = mysql_result(mysql_query("SELECT COUNT(`id`) FROM `library`"), 0);
if($stories > 0){
	$result = mysql_query("SELECT * FROM `library_cats`");
	while($cat = mysql_fetch_assoc($result)){
		$cat_stories = mysql_result(mysql_query("SELECT COUNT(`id`) FROM `library` WHERE `id_cat` = '".$cat['id']."'"), 0);
echo '<a href="lib.php?act=cat_view&amp;id='.$cat['id'].'">'.$cat['name'].'</a> ('.$cat_stories.')<br/>';
	}
}else{
	echo 'Разделов еще нет';
}
echo '</div>';
nav();

break;

case 'cat_view':

$id = intval($_REQUEST['id']);

$cat = mysql_fetch_assoc(mysql_query("SELECT * FROM `library_cats` WHERE `id` = '$id'"));

if(isset($cat['id'])){
echo '<div class="phdr">'.$cat['name'].'</div><div class="bmenu">';
	$result = mysql_query("SELECT * FROM `library` WHERE `id_cat` = '$id' ORDER BY `time` DESC");
	$story = mysql_fetch_assoc($result);
	if($story > 0){
 		do
		{
 		printf('<a href="index.php?act=story_view&amp;id=%s">%s</a> (%s)<br/>', $story['id'], $story['title'], date('d.m.y / H:i', $story['time']));
 		}
 		while($story = mysql_fetch_assoc($result));
	}else{
 		echo 'Рассказов в этом разделе еще нет';
	}
	echo '</div>';
	nav2('./', 'назад');
}else{
	error('Это категории не существует!');
	nav2('./', 'назад');
}

break;

case 'story_view':

$id = intval($_REQUEST['id']);

$result = mysql_query("SELECT * FROM `library` WHERE `id` = '$id'");
$story = mysql_fetch_assoc($result);

if(isset($story['id'])){
echo '<div class="bmenu">'.$story['title'].'</div><div class="bmenu">'.nl2br($story['text']).'<br/><br/><i>Автор: '.$story['authour'].'<br/>Размещено: '.date('d.m.y / H:i', $story['time']).'</i></div>';
	nav2('./', 'назад');
}else{
	error('Этой статьи не существует!');
	nav2('./', 'назад');
}
break;

}

require("../system/end.php");
?>